# Permissions needed

- Give this folder full permissions to IIS_USER and IUSR and USERS